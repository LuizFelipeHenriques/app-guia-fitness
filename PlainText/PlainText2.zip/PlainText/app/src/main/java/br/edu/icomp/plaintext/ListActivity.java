package br.edu.icomp.plaintext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.inputmethodservice.KeyboardView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_list);

    setTitle("Grupos Musculares");


    }
    public void entrarClicando(View view) {
//        Button butombros = (Button) findViewById(R.id.Ombros1);
//        Button butCostas = findViewById(R.id.Costas1);
//        Button butPeito = findViewById(R.id.Peito1);
//        butombros.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(this, SubListActivity.class);
//                startActivity(intent);
//            }
//        });
//        butCostas.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(this, SubListActivity.class);
//                startActivity(intent);
//            }
//        });
//
//        butPeito.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(this, SubListActivity.class);
//                startActivity(intent);
//            }
//        });
//
//
//
        Intent intent = new Intent(this, SubListActivity.class);
            startActivity(intent);

    }



}